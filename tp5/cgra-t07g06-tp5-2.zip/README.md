# CGRA 2020/2021

## Group T07G06

## TP 5 Notes

- In exercise 1 we had difficulties in understanding how to change the color of the bule according to the view and not the coord position. 
Also, had a hard time trying to figure out how to understand how variables go from .vert to .frag...
- In exercise 2, we had some troubles figuring out how to repeat the texture and also took sometime to synchronise both of the images moving coords. Overall, it was a very  usefull class to understand shaders
