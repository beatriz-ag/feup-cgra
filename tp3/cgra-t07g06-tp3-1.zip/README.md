# CGRA 2020/2021

## Group T07G06

## TP 3 Notes

- In this exercise we initially had some troubles in how to create more than one normal to the same vertice but once we understood how, the exercise was quite accessible and interesting.
 We also found it very useful that we could "play" with the scene with the parameters already given to us,