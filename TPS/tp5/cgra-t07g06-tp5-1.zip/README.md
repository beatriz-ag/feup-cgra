# CGRA 2020/2021

## Group T0xG0y

## TP 5 Notes

(add your main observations/remarks about your experiments here, in a bulleted list, and remove this line. Some examples below)

- In exercise 1 we had difficulties in understanding how to change the color of the bule according to the view and not the coord position. 
Also, had a hard time trying to figure out how to understand how variables go from .vert to .frag...
- In exercise 2 we had difficulties in Y