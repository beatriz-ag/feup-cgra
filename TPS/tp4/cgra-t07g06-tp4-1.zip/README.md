# CGRA 2020/2021

## Group T07G06

## TP 4 Notes

- In the first exercise, we spent some time trying to understand ~the "clamp to edge" texture and  also got initially confused with the textCoords definition.
- In exercise 2 we had difficulties in Y