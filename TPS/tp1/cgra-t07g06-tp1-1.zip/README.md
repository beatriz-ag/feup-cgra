# CGRA 2020/2021

## Group T07G06

## TP 1 Notes

- In exercise 1 we found interesting creating various objects only by using triangles. There wasn't any difficulty in particular as the subject was well explained during class. 
- In exercise 2 we decided to explore the various components by changing the parameters and observing its results. As the exercise was very similar to the first one, we also didn't
 have any particular difficult. The more challenging part was to find out how to change colors and to be able to spin the axis.