# CGRA 2020/2021

## Group T07G06

## TP 2 Notes

- In exercise 1, we initially found difficult to understand how to construct the tangram but when understood, the exercise was very interesting. We also had a few difficulties in the rotations/scales of the parallelogram but we overcame it.
- In exercise 2, the difficulty was on understanding which transitions to apply to the matrixes in order to create the "frame".
- Finally, in the final exercise, we hadn't any particular difficulty as everything was understood and trained in the previous exercises.