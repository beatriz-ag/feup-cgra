# CGRA 2020/2021

## Group T07G06

## TP 4 Notes

- In the first exercise, we spent some time trying to understand ~the "clamp to edge" texture and  also got initially confused with the textCoords definition.
- In the second exercise, although we hadn't still talked about filtering in the theoretical classes the practical classes teacher explained it quite well but we still weren't sure how to apply it to the MyUnitCubeQuad, code wise. Once this small details were understood, we finished the exercises nicely.